#This program gets two values from a DB into lineEdits.
import sys
from patient import *

import MySQLdb as mdb

con = mdb.connect('localhost', 'team1', 'test623', 'leuke1'); 

class MyForm(QtGui.QMainWindow):
  def __init__(self,parent=None):
     QtGui.QWidget.__init__(self,parent)
     self.ui = Ui_MainWindow()
     self.ui.setupUi(self)
     QtCore.QObject.connect(self.ui.pushButton,QtCore.SIGNAL('clicked()'),self.insertvalues)
   

  def insertvalues(self):
         
     with con:
    
        cur = con.cursor()
        aadhar = str(self.ui.lineEdit.text())
        pid = str(self.ui.lineEdit_3.text())
	pname = str(self.ui.lineEdit_4.text())
	addr1 = str(self.ui.lineEdit_5.text())
	addr2 = str(self.ui.lineEdit_6.text())	
        mobile = str(self.ui.lineEdit_2.text())
        cur.execute('INSERT INTO patient VALUES(%s,%s,%s,%s,%s,%s)',(pid,pname,addr1,addr2,aadhar,mobile))
        con.commit()
        

if __name__ == "__main__":  
    app = QtGui.QApplication(sys.argv)
    myapp = MyForm()
    myapp.show()
    sys.exit(app.exec_())
