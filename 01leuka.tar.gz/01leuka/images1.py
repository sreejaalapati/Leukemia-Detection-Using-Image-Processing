#This program gets two values from a DB into lineEdits.
import sys
import os 
from images import *

class MyForm(QtGui.QMainWindow):
  def __init__(self,parent=None):
     QtGui.QWidget.__init__(self,parent)
     self.ui = Ui_MainWindow()
     self.ui.setupUi(self)
     QtCore.QObject.connect(self.ui.pushButton,QtCore.SIGNAL('clicked()'),self.checkfile1)
     #QtCore.QObject.connect(self.ui.pushButton_2,QtCore.SIGNAL('clicked()'),self.checkfile2)
     #QtCore.QObject.connect(self.ui.pushButton_3,QtCore.SIGNAL('clicked()'),self.checkfile3)
   

  def checkfile1(self):        
         
        fname = str(self.ui.lineEdit.text())
        if (os.path.isfile(fname)):
  	  print ' file exists'
	  os.system("python clrtobw.py")
	else:
  	  print ' file does not exists' 
'''
  def checkfile2(self):        
         
        fname = str(self.ui.lineEdit_2.text())
        if (os.path.isfile(fname)):
  	  print ' file exists'
	else:
  	  print ' file does not exists'

  def checkfile3(self):        
         
        fname = str(self.ui.lineEdit_3.text())
        if (os.path.isfile(fname)):
  	  print ' file exists'
	else:
  	  print ' file does not exists'      
'''
if __name__ == "__main__":  
    app = QtGui.QApplication(sys.argv)
    myapp = MyForm()
    myapp.show()
    sys.exit(app.exec_())
