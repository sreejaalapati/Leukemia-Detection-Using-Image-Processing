import os
import cv2
import numpy as np
#from cv2 import cv

#method = cv.CV_TM_SQDIFF_NORMED

# Read the images from the file
image1 = cv2.imread('im001.jpg')
image2 = cv2.imread('im003.jpg')
image3 = cv2.imread('im005.jpg')

cv2.resize(image1, (0, 0), fx=0.5, fy=0.5)

# Display the original image with the rectangle around the match.
cv2.imshow('image',image1)

# The image is only displayed if we call this
cv2.waitKey(4000)

print('Bladder Identified')


