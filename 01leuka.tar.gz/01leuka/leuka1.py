#This program gets two values from a DB into lineEdits.
import sys
import os
from leuka import *

class MyForm(QtGui.QMainWindow):
  def __init__(self,parent=None):
     QtGui.QWidget.__init__(self,parent)
     self.ui = Ui_MainWindow()
     self.ui.setupUi(self)
     QtCore.QObject.connect(self.ui.pushButton_5,QtCore.SIGNAL('clicked()'),self.pdetails)
     QtCore.QObject.connect(self.ui.pushButton,QtCore.SIGNAL('clicked()'),self.psympts)
     QtCore.QObject.connect(self.ui.pushButton_2,QtCore.SIGNAL('clicked()'),self.ptstrslts)
     QtCore.QObject.connect(self.ui.pushButton_3,QtCore.SIGNAL('clicked()'),self.imgfls)
     QtCore.QObject.connect(self.ui.pushButton_4,QtCore.SIGNAL('clicked()'),self.wbcidn)
     #QtCore.QObject.connect(self.ui.pushButton_6,QtCore.SIGNAL('clicked()'),self.gnrep)
        

  def psympts(self):
	os.system("python psymptoms1.py")

  def pdetails(self):
	os.system("python patientdtls1.py")

  def ptstrslts(self):
	os.system("python ptests1.py")

  def imgfls(self):
	os.system("python images1.py")

  def wbcidn(self):
	os.system("python cntblck.py")

#  def gnrep(self):
#	os.system("python genrep1.py")
       
          
if __name__ == "__main__":  
    app = QtGui.QApplication(sys.argv)
    myapp = MyForm()
    myapp.show()
    sys.exit(app.exec_())
