#This program gets two values from a DB into lineEdits.
import sys
import os
#import xlsxwriter
from ptests import *
from reportlab import platypus
from reportlab.lib.styles import ParagraphStyle as PS
from reportlab.platypus import SimpleDocTemplate

import MySQLdb as mdb

con = mdb.connect('localhost', 'team1', 'test623', 'leuke1'); 

class MyForm(QtGui.QMainWindow):
  def __init__(self,parent=None):
     QtGui.QWidget.__init__(self,parent)
     self.ui = Ui_MainWindow()
     self.ui.setupUi(self)
     QtCore.QObject.connect(self.ui.pushButton,QtCore.SIGNAL('clicked()'),self.insertvalues)
     QtCore.QObject.connect(self.ui.pushButton_2,QtCore.SIGNAL('clicked()'),self.getdetails)

  def insertvalues(self):
         
     with con:
    
        cur = con.cursor()
        pid = str(self.ui.lineEdit_3.text())
	t1 = str(self.ui.lineEdit_4.text())
	t2 = str(self.ui.lineEdit_5.text())
	cur.execute('INSERT INTO ptestresults(pid,t1,t2) VALUES(%s,%s,%s)',(pid,t1,t2))
        con.commit()
   
  def getdetails(self):

      with con:
    
          cur = con.cursor()
          pid = str(self.ui.lineEdit_3.text())
          cur.execute('SELECT count(*) FROM ptestresults where pid like %s AND (ptestresults.t1 = "P" OR ptestresults.t2 = "P")',['%'+ pid + '%']); 
          result = cur.fetchall()
          for row in result:
            tcount = row[0]
            # print tcount
	  cur.execute('SELECT s1,s2,s3,s4,s5,s6,s7,s8,s9,s10 FROM psymptoms where pid like %s ',['%'+ pid + '%']); 
          result1 = cur.fetchall()
          cnt1 = 0
          result2 = str(" ")
          for row in result1:
              if row[0] != 'N': 
		 cnt1 = cnt1+1
                 result2 = result2 + str("___________________ You have Severe Pain in the upper right of the abdomen ________________________") 
	      if row[1] != 'N': 
		 cnt1 = cnt1+1
		 result2 = result2 + str("____________________ You have Severe Pain in the upper right of the abdomen _________________________") 
	      if row[2] != 'N': 
		 cnt1 = cnt1+1
                 result2 = result2 + str("_____________ Your abdominal pain is lasting for several hours ______________") 
	      if row[3] != 'N': 
		 cnt1 = cnt1+1
	         result2 = result2 + str(" Your pain is increasing after heavy meals ")
	      if row[4] != 'N': 
		 cnt1 = cnt1+1
	         result2 = result2 + str(" Your pain is increasing with deep breaths")
	      if row[5] != 'N': 
		 cnt1 = cnt1+1
	         result2 = result2 + str(" You are suffering from heart burn & indigestion")
	      if row[6] != 'N': 
		 cnt1 = cnt1+1
	         result2 = result2 + str(" You have a feeling of abdominal fullness")
	      if row[7] != 'N': 
		 cnt1 = cnt1+1
	         result2 = result2 + str(" You are suffering from low to high fever ")
	      if row[8] != 'N': 
		 cnt1 = cnt1+1
	         result2 = result2 + str(" You are shaking with chills")
	      if row[9] != 'N': 
		 cnt1 = cnt1+1
	         result2 = result2 + str(" Your urine color is abnormal ")
              # print cnt1
	  if (tcount > 0):
	    # print "Consult Specialist immediately as +ve test results are there"
            result2 = result2 + str("Consult Specialist immediately as +ve test results are there")
	  if ((tcount == 0) and (cnt1 > 5)):
	    # print "Consult Specialist immediately as above mentioned +ve symptoms are there"
            result2 = result2 + str("Consult Specialist immediately as above mentioned +ve symptoms are there")
	  if ((tcount == 0) and (cnt1 <= 5)):
	    # print "Consult Specialist as above mentioned +ve symptoms are there"
            result2 = result2 + str("Consult Specialist as above mentioned +ve symptoms are there")
	  items = []
	  items.append(platypus.Paragraph(result2,PS('body')))
	  doc = SimpleDocTemplate('medrep1.pdf')
          doc.multiBuild(items)

  
if __name__ == "__main__":  
    app = QtGui.QApplication(sys.argv)
    myapp = MyForm()
    myapp.show()
    sys.exit(app.exec_())
